export default {
  api_url: 'http://127.0.0.1:8080/api/v1',
  currency: 'INR',
  currency_symbol: '&#8377'
};